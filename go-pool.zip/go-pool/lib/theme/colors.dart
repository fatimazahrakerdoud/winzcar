import 'package:flutter/material.dart';

// Color iconBgColor = Color(0xff424450);
// Color iconFgColor = Color(0xff34c6ad);
Color subtitle = Color(0xff5E5C73);
Color darkBg = Color(0xff21202B);
Color primaryColor = Color(0xff0FC874);
Color backgroundColor = Color(0xffEBF3F9);
