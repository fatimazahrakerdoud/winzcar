class LoginInteractor {
  void loginWithPhone(String isoCode, String mobileNumber) {}
  void loginWithFacebook() {}
  void loginWithGoogle() {}
}
