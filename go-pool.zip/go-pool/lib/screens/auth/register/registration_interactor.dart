class RegistrationInteractor {
  void register(String phoneNumber, String name, String email) {}

  void goBack() {}
}
