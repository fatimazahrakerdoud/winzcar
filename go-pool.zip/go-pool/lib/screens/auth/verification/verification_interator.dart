class VerificationInteractor {
  void verificationDone() {}
  void verifyNumber() {}
}
