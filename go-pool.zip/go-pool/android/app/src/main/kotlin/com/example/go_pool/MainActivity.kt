package com.example.go_pool

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
